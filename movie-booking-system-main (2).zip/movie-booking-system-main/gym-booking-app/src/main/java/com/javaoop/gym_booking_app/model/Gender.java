package com.javaoop.gym_booking_app.model;

/**
 * Represents the gender of a member.
 */
public enum Gender {
    MALE,
    FEMALE,
    OTHER
}