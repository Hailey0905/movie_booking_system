package com.javaoop.gym_booking_app.model;

/**
 * Represents the role of a user.
 */
public enum Role {
    MEMBER,
    ADMIN,
    COACH
}