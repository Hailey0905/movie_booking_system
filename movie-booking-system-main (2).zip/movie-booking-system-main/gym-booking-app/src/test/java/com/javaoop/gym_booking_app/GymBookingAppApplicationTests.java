package com.javaoop.gym_booking_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymBookingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
