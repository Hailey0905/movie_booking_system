資料庫跟 movie-booking-app 那邊的安裝方式差不多

除了資料庫名稱叫做 `gym_booking` 以外。 
